<!doctype html>
<html>

<head>
    <title> Prøve PHP </title>
</head>


<body>
<h1> Prøve PHP </h1>
<h3> Ida Emilie </h3>
<h3> 31.01.2021 </h3>


<?php
include "variabler.php";
echo "<br><br>";
echo "<br><br>";
include "if.php";
echo "<br><br>";
echo "<br><br>";
include "iflokke.php";
echo "<br><br>";
echo "<br><br>";
include "tolokker.php";
echo "<br><br>";
echo "<br><br>";
include "skjema.php";
echo "<br><br>";
echo "<br><br>";
include "mottaskjema.php";



?>




</body>

</html>