<?php

$tegn = "* ";
$tall = 0;



for ($i = 0; $i <= 4; $i++) {
    for ($x = 0; $x <= $tall; $x++) {
        
        echo "$tegn";
       
        
    }
echo "<br><br>";
$tall = $tall += 1;
}


?>