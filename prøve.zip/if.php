<?php

$tall = rand(1,100);


if ($tall < 50) {
echo "Tallet $tall er mindre en 50";
}

elseif ($tall == 50) {
echo "Tallet $tall er like stort som 50";
}

else { 
echo "Tallet $tall er større enn 50";
}


?>