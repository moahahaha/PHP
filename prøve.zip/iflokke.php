<?php

$antall = 1;
$y = 10;


while ("$antall" <= 20) {
    if ($antall == $y) {
        echo "Y";
    }
    else {
    echo "X";
    }
    echo "<br><br>";
    $antall = $antall + 1;
    
}




?>