<!doctype html>
<html>
<head>

</head>

<body>

<form action="mottaskjema.php" method = "GET">
    
    Ditt navn
    <input type= "text" name="dittnavn">
    <p></p>
    Inntekt 2020
    <input type= "text" name="inntekt2020">
    <p></p>
    Inntekt 2021
    <input type= "text" name="inntekt2021">
    <p></p>  
    Inntekt 2022 
    <input type= "text" name="inntekt2022">
    <p></p>  


    <input type="submit" name = "sendinn" value="Send inn">
</form>

</body>
</html>